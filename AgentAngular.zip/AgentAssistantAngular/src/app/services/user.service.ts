import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
const url = 'http://localhost:8080/users';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor(private http: HttpClient) { }

  addCustomer(newUser: any): Observable<any> {
    return this.http.post(url + '/addUser', newUser);
  }

  getAllFreeManagers(): Observable<any> {
    return this.http.get(url + '/getAllFreeManagers');
  }

  getAllFreeAgents(): Observable<any> {
    return this.http.get(url + '/getAllFreeAgents');
  }

  getAllFreeAgentsDto(): Observable<any> {
    return this.http.get(url + '/getAllFreeAgentsDto');
  }

  updateUser(user: any): Observable<any> {
    return this.http.post(url + '/updateUser', user);
  }

  getCompaniesByPage(pageS: number, sizeS: number, sortByS: string, directionS: string, filterS: string): Observable<any> {
    return this.http.get(url + '/getAllUsersByPage',
      {params: {page: String(pageS),
          size: String(sizeS),
          sortBy: sortByS,
          direction: directionS,
          filter: filterS}});
  }

  deleteUser(loginUser: string): Observable<any> {
    return this.http.delete(url + '/deleteUserByLogin',
      {params: {login: loginUser}});
  }
}
