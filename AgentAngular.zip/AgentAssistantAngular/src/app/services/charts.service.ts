import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';

const url = 'http://localhost:8080/charts';

@Injectable({
  providedIn: 'root'
})
export class ChartsService {

  constructor(private http: HttpClient) { }

  getSalesDuringYear(): Observable<any> {
    return this.http.get(url + '/salesDuringYear');
  }

  getLastWeekAddedPolicies(): Observable<any> {
    return this.http.get(url + '/getLastWeekAddedPolicies');
  }

  getLastWeekCreatedCustomers(): Observable<any> {
    return this.http.get(url + '/getLastWeekCreatedCustomers');
  }

  getPoliciesByKind(): Observable<any> {
    return this.http.get(url + '/getPoliciesByKind');
  }

  getAllPoliciesByKind(): Observable<any> {
    return this.http.get(url + '/getAllPoliciesByKind');
  }
}
