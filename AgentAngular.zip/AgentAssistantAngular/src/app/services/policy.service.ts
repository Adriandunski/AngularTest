import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable} from 'rxjs';
const url = 'http://localhost:8080/policies';

@Injectable({
  providedIn: 'root'
})
export class PolicyService {

  constructor(private http: HttpClient) { }

  addPolicy(policy: any): Observable<any> {
    return this.http.post(url + '/addPolicyRequest', policy);
  }

  getPoliciesByPage(pageS: number, sizeS: number, sortByS: string, directionS: string, filterS: string): Observable<any>{

    return this.http.get(url + '/getPoliciesByPage',
      {params: {page: String(pageS),
          size: String(sizeS),
          sortBy: sortByS,
          direction: directionS,
          filter: filterS}});
  }

  getExpirePolicies(): Observable<any> {
    return this.http.get(url + '/expirePolicies');
  }

  deleteById(id: string): Observable<any> {
    return this.http.delete(url + '/deleteById', {params: {policeId: id}});
  }

  pay(id: string): Observable<any> {
    return this.http.get(url + '/pay', {params: {policeId: id}});
  }
}
