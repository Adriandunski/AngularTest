import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';
import {FormBuilder} from '@angular/forms';

@Component({
  selector: 'aga-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss']
})
export class EditUserComponent implements OnInit {
  agentForm: any;
  constructor(@Inject(MAT_DIALOG_DATA) public agent: any, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.agentForm = this.fb.group({
      login: [this.agent.login],
      name: [this.agent.name],
      lastname: [this.agent.lastname],
      email: [this.agent.email],
      phoneNumber: [this.agent.phoneNumber],
      branch: [this.agent.branch],
      role: [this.agent.role]
    });
  }
}
