import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {UserService} from '../services/user.service';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {FormControl} from '@angular/forms';
import {MatDialog} from '@angular/material/dialog';
import {merge, of} from 'rxjs';
import {catchError, map, startWith, switchMap} from 'rxjs/operators';
import {MatSnackBar} from '@angular/material/snack-bar';
import {DeleteMatDialogComponent} from '../other/delete-mat-dialog/delete-mat-dialog.component';
import {UpdateUserComponent} from './update-user/update-user.component';
import {TokenStorageService} from '../services/security/token-storage.service';

@Component({
  selector: 'aga-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent implements AfterViewInit {
  usersArray: Array<any>;
  filter = new FormControl('');
  columnsDoDisplayUser = ['name', 'lastname', 'phoneNumber', 'email', 'role', 'delete', 'edit'];

  resultsLength = 0;
  isLoadingResults = true;
  isRateLimitReached = false;

  isLoggedIn = false;
  adminAccess = false;


  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  // tslint:disable-next-line:max-line-length
  constructor(private userService: UserService, private dialog: MatDialog, private snackBar: MatSnackBar, private tokenStorageService: TokenStorageService) { }

  ngAfterViewInit(): void {
    this.isLoggedIn = !!this.tokenStorageService.getToken();

    if (this.isLoggedIn) {
      const user = this.tokenStorageService.getUser();
      this.adminAccess = user.roles.includes('ROLE_ADMIN');
    }

    merge(this.sort.sortChange, this.paginator.page, this.filter.valueChanges)
      .pipe(
        startWith({}),
        switchMap(() => {
          this.isLoadingResults = true;
          return this.userService.getCompaniesByPage(this.paginator.pageIndex, this.paginator.pageSize,
            this.sort.active, this.sort.direction, this.filter.value);
        }),
        map(data => {
          this.isLoadingResults = false;
          this.isRateLimitReached = false;
          this.resultsLength = data.sizeTable;

          return data;
        }),
        catchError(() => {
          this.isLoadingResults = false;
          this.isRateLimitReached = true;
          return of([]);
        })
      ).subscribe(users => {
        console.log(users);
        this.usersArray = users.data;
    });
  }

  filterData($event: KeyboardEvent): void {
    this.filter.setValue((event.target as HTMLInputElement).value);
  }

  deleteAgent(element: any): void {
    const agentWarn = 'User: ' + element.name + ' ' + element.lastname;

    if (element.role ) {

    }

    const refDelete = this.dialog.open(DeleteMatDialogComponent, {data: agentWarn});

    refDelete.afterClosed().subscribe(close => {
      if (close === 'true') {
        element.branch = null;
        console.log(element);
        this.userService.deleteUser(element.login).subscribe(() => {},
          error => {},
          () => {
            console.log('Koniec');
            this.openSnackBar('Usunieto usera: ' + element.name + ' ' + element.lastname);
            this.ngAfterViewInit();
          });
      }
    });
  }

  updateAgent(element: any): void {
    const refUpdateAgent = this.dialog.open(UpdateUserComponent, {data: element});

    refUpdateAgent.afterClosed().subscribe(close => {
      if (close === false) {
        console.log('Brak aktualizacji');
      } else if (close !== undefined) {
        this.userService.updateUser(close).subscribe(() => {},
          error => {},
          () => {
            console.log('Koniec');
            this.openSnackBar('Zaaktualizowano agenta');
            this.ngAfterViewInit();
          });
      }
    });
  }

  public openSnackBar(message: string): void {
    this.snackBar.open(message, 'zamknij', {duration: 4000});
  }
}
