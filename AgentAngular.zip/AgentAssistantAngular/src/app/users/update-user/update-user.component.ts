import {Component, Inject, OnInit} from '@angular/core';
import {MAT_DIALOG_DATA} from '@angular/material/dialog';
import {FormBuilder} from '@angular/forms';

@Component({
  selector: 'aga-update-user',
  templateUrl: './update-user.component.html',
  styleUrls: ['./update-user.component.scss']
})
export class UpdateUserComponent implements OnInit {
  selectedRole: string;
  userForm: any;
  roleList = ['ROLE_ADMIN', 'ROLE_MANAGER', 'ROLE_AGENT'];
  constructor(@Inject(MAT_DIALOG_DATA) public agent: any, private fb: FormBuilder) { }

  ngOnInit(): void {
    this.userForm = this.fb.group({
      login: [this.agent.login],
      name: [this.agent.name],
      lastname: [this.agent.lastname],
      email: [this.agent.email],
      phoneNumber: [this.agent.phoneNumber],
      branch: [this.agent.branch],
      role: [this.agent.role]
    });
    this.selectedRole = this.agent.role;
  }
}
