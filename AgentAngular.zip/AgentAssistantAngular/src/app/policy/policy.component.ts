import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {FormControl} from '@angular/forms';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {merge, of} from 'rxjs';
import {catchError, map, startWith, switchMap} from 'rxjs/operators';
import {MatDialog} from '@angular/material/dialog';
import {PolicyService} from '../services/policy.service';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'aga-policy',
  templateUrl: './policy.component.html',
  styleUrls: ['./policy.component.scss']
})
export class PolicyComponent implements AfterViewInit {
  policiesArray: Array<any>;
  filter = new FormControl('');
  columnsToDisplay = ['policyNumber', 'kindOfPolicy', 'customer', 'user', 'sumInsured', 'payStatus', 'daysToPay', 'daysToEnd', 'pay', 'end'];

  resultsLength = 0;
  isLoadingResults = true;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  constructor(private dialog: MatDialog, private policyService: PolicyService, private snackBar: MatSnackBar) { }

  ngAfterViewInit(): void {
    this.sort.sortChange.subscribe(() => this.paginator.pageIndex = 0);
    this.filter.valueChanges.subscribe(() => this.paginator.pageIndex = 0);

    merge(this.sort.sortChange, this.paginator.page, this.filter.valueChanges)
      .pipe(
        startWith({}),
        switchMap(() => {
          this.isLoadingResults = true;
          // console.log('index = ', this.paginator.pageIndex);
          // console.log('size = ', this.paginator.pageSize);
          // console.log(this.sort.active);
          // console.log(this.sort.direction);
          return this.policyService.getPoliciesByPage(this.paginator.pageIndex, this.paginator.pageSize,
            this.sort.active, this.sort.direction, this.filter.value);
        }),
        map(data => {
          this.isLoadingResults = false;
          this.resultsLength = data.sizeTable;

          return data;
        }),
        catchError(() => {
          this.isLoadingResults = false;
          return of([]);
        })
      ).subscribe(policies => {
      this.policiesArray = policies.data;
      console.log(policies);
    });
  }

  filterData($event: KeyboardEvent): void {
    this.filter.setValue((event.target as HTMLInputElement).value);
  }

  pay(element: any): void {
    this.policyService.pay(String(element.policyNumber)).subscribe(
      () => {},
      error => {},
      () => {
        this.ngAfterViewInit();
        this.openSnackBar('Zapłacono');
      });
  }

  delete(element: any): void {
    this.policyService.deleteById(String(element.policyNumber)).subscribe(
      () => {},
        error => {},
      () => {
        this.ngAfterViewInit();
        this.openSnackBar('Usunieto polise');
      });
  }

  public openSnackBar(message: string): void {
    this.snackBar.open(message, 'zamknij', {duration: 4000});
  }
}
