import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms';
import {AuthService} from '../services/security/auth.service';
import {HttpErrorResponse} from '@angular/common/http';
import {TokenStorageService} from '../services/security/token-storage.service';
import {Router} from '@angular/router';
import {MatSnackBar} from '@angular/material/snack-bar';

@Component({
  selector: 'aga-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  readonly loginForm: FormGroup;
  hide = true;
  constructor(fb: FormBuilder,
              private authService: AuthService,
              private tokenStorageService: TokenStorageService,
              private router: Router,
              private snackBar: MatSnackBar) {
    this.loginForm = fb.group({
      login: [],
      password: []
    });
  }

  ngOnInit(): void {
  }

  login(): void {
    this.authService.login(this.loginForm.value).subscribe(user => {
      console.log(user);
      this.tokenStorageService.saveToken(user.token);
      this.tokenStorageService.saveUser(user);
      window.location.replace('');
    }, (error: HttpErrorResponse) => {
      this.loginForm.controls.login.setValue(null);
      this.loginForm.controls.password.setValue(null);

      this.snackBar.open('Login lub hasło są niepoprawne.', 'zamknij',
        {duration: 2000,
        panelClass: 'test'});
      console.log(error);
    });
  }
}
